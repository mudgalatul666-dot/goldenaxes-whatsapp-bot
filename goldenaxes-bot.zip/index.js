const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const app = express();
app.use(bodyParser.json());
const TOKEN = process.env.WHATSAPP_TOKEN;
const VERIFY_TOKEN = "goldenaxes9266";
const PHONE_ID = "923809060741931";
app.get('/webhook', (req, res) => {
  if (req.query['hub.verify_token'] === VERIFY_TOKEN) {
    res.send(req.query['hub.challenge']);
  } else {
    res.sendStatus(403);
  }
});
app.post('/webhook', async (req, res) => {
  try {
    const entry = req.body.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
    if (entry) {
      const from = entry.from;
      const msg = entry.text?.body || "Hi";
      await axios.post(`https://graph.facebook.com/v20.0/${PHONE_ID}/messages`, {
        messaging_product: "whatsapp",
        to: from,
        text: { body: `Namaste! Golden Axes 9266 here! Aapne likha: "${msg}". Team jald contact karegi. Type 1 for Health, 2 for Life.` }
      }, {
        headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' }
      });
    }
    res.sendStatus(200);
  } catch (e) { console.log(e.message); res.sendStatus(200); }
});
app.get('/', (req, res) => res.send('GoldenAxes Bot LIVE'));
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Live'));
